import { Component, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EdumanModule } from '../eduman.module';
import { ApiService } from 'src/app/providers/api/api.service';
import { ActivatedRoute } from '@angular/router';
import { VideoService } from 'src/app/providers/video/video.service';

declare var $: any;


@Component({
  selector: 'app-go-to-course',
  standalone: true,
  imports: [CommonModule, EdumanModule],
  templateUrl: './go-to-course.component.html',
  styleUrls: ['./go-to-course.component.scss'],
})
export class GoToCourseComponent {
  @ViewChild('myVideo') videoPlayerDuration: ElementRef | any;
  courseList: any = [];
  courseSno: any;
  courseDetails: any;
  // videoPlayer: any;
  isShowVideo: boolean = false;
  articale: any;
  // videoDuration: number = 0.0;
  remainder: number = 0.0;
  quotient: number = 0.0;
  cartTotalHours: string = '00:03:15.471';
  dateTime = new Date();
  videoUrl: any;

  videoSegments: VideoSegment[] = [];
  totalDuration = 0;
  currentTime = 0;
  progress = 0;
  isPlay = false;
  isMuted = false;
  isFullScreen = false;
  videoElement: HTMLVideoElement | any;
  currentSegmentIndex = 0;
  @ViewChild('videoPlayer') videoPlayer!: ElementRef;
  @ViewChild('progressBar') progressBar!: ElementRef;
  isDragging = false;
  isLoading = false;

  selectedVideo: any;


  constructor(
    private api: ApiService,
    private route: ActivatedRoute,
    private videoService: VideoService
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      if (params) {
        this.courseSno = params['courseSno'];
        this.getCourseDetails();
      }
    });
  }

  toggleSection(curriculum: any) {
    curriculum.isExpanded = !curriculum?.isExpanded; // Toggle the expanded state
  }

  selectVideo(lecture: any): void {
    console.log(lecture);
    if (lecture?.videoSno) {
      let video = lecture?.videoSno?.split('/');
      console.log(video);
      this.selectedVideo = video[video?.length - 1];
      console.log(this.selectedVideo);
      this.currentSegmentIndex = 0;
      this.totalDuration = 0;
      this.currentTime = 0;
      this.progress = 0;
      this.getVideoDuration();
    } else {
      this.isShowVideo = false;
      this.articale = lecture?.articale;
    }
  }


  getCourseDetails() {
    let params: any = {};
    params.courseSno = this.courseSno;
    this.api
      .get('8010/api/lnt/get_courses_details', params)
      .subscribe((result) => {
        if (result) {
          this.courseDetails = result?.data?.length ? result?.data[0] : null;
          let lectureLength: number = 0;
          let totalVideoLength: number = 0;
          let totalArticaleLength: number = 0;
          let totalResourceLength: number = 0;
          if (this.courseDetails?.curriculum[0]?.lecture?.length) {
            this.selectVideo(this.courseDetails?.curriculum[0]?.lecture[0]);
            // this.videoPlayer?.pause();
          }
          for (let curriculum of this.courseDetails?.curriculum) {
            lectureLength = lectureLength + (curriculum?.lecture?.length ?? 0);
            for (let lecture of curriculum?.lecture) {
              totalVideoLength = totalVideoLength + (lecture?.videoSno ? 1 : 0);
              totalArticaleLength =
                totalArticaleLength + (lecture?.articale ? 1 : 0);
              totalResourceLength =
                totalResourceLength + (lecture?.resourcesSno ? 1 : 0);
            }
          }
          this.courseDetails.lectureLength = lectureLength ?? 0;
          this.courseDetails.totalVideoLength = totalVideoLength ?? 0;
          this.courseDetails.totalArticaleLength = totalArticaleLength ?? 0;
          this.courseDetails.totalResourceLength = totalResourceLength ?? 0;
          console.log(this.courseDetails);
        }
      });
  }

  roundDuration(durationString: any) {
    const parts = durationString.split(":");
    const seconds = parseInt(parts[2]);
    const roundedSeconds = Math.round(seconds / 100) * 100;  // Round to nearest hundredth
    return parts[0] + ":" + parts[1] + ":" + roundedSeconds.toString().padStart(2, "0");
  }

  downloadResources(url: any) {
    const download = document.createElement('a');
    download.href = url;
    download.download = url.split('/').pop();
    download.click();
  }

  startVideoStreaming(): void {
    this.videoService.getVideoChunk().subscribe((blob: any) => {
      const videoBlob = new Blob([blob], { type: 'video/mp4' });
      this.videoUrl = URL.createObjectURL(videoBlob);
    });
  }

  async getVideoDuration(): Promise<void> {
    const params = {
      fileName: this.selectedVideo
    };
    try {
      const result: any = await this.api.get('8010/api/lnt/get_video_duration', params).toPromise();
      const duration = result?.duration ?? 0;
      this.totalDuration = duration;
      const segmentCount = duration / 30;

      for (let i = 0; i < segmentCount; i++) {
        const startTime = i * 30;
        const endTime = startTime + 30;
        this.videoSegments.push({
          startTime,
          endTime,
          data: null
        });
      }
      await this.getVideo();
    } catch (error) {
      console.error('Error fetching video duration:', error);
    }
  }

  async getVideo(): Promise<void> {
    try {
      const newBlobUrl = await this.fetchVideoSegment(0, 30, this.selectedVideo);
      this.videoSegments[0].data = newBlobUrl;
      this.videoElement = this.videoPlayer.nativeElement;
      this.loadPlayer();
      this.videoElement.src = this.videoSegments[0].data;
      this.videoElement.play();
    } catch (error) {
      console.error('Error fetching video:', error);
    }
  }

  loadPlayer(): void {
    if (!this.videoElement) return;

    this.videoElement.addEventListener('timeupdate', () => {
      console.log(!this.isDragging);
      if (!this.isDragging) {
        this.progress = (((this.videoSegments[this.currentSegmentIndex].startTime + this.videoElement.currentTime) / this.totalDuration) * 100) || 0;
        this.currentTime = this.videoSegments[this.currentSegmentIndex].startTime + this.videoElement.currentTime;

        if (!this.isLoading && !this.videoSegments[this.currentSegmentIndex + 1]?.data && this.videoElement.currentTime > 1 && Math.floor(this.videoElement.currentTime) >= 20 && this.currentSegmentIndex < (this.videoSegments?.length - 1)) {
          this.isLoading = true;
          this.fetchVideoSegment(this.videoSegments[this.currentSegmentIndex + 1].startTime, this.videoSegments[this.currentSegmentIndex + 1].endTime, this.selectedVideo).then((newBlobUrl: any) => {
            this.isLoading = false;
            this.videoSegments[this.currentSegmentIndex + 1].data = newBlobUrl;
          });
        }

        if (!this.isLoading && this.videoElement.currentTime > 1 && (Math.floor(this.videoElement.currentTime) % 29 === 0) && this.currentSegmentIndex < (this.videoSegments?.length - 1)) {
          if ((Math.floor(this.videoElement.currentTime) % 29 === 0) && this.videoSegments[this.currentSegmentIndex + 1]?.data) {
            this.currentSegmentIndex++;
          }
          this.videoElement.src = this.videoSegments[this.currentSegmentIndex].data;
          this.videoElement.play();
        }
      }
    });

    this.videoElement.addEventListener('play', () => {
      this.isPlay = true;
    });

    this.videoElement.addEventListener('pause', () => {
      this.isPlay = false;
    });

    $('.popover-area').on('click', () => {
      if (this.videoElement.paused) {
        if ((this.currentSegmentIndex === (this.videoSegments?.length - 1)) && (Math.floor(this.progress) % 100 === 0)) {
          this.currentSegmentIndex = 0;
          this.videoElement.src = this.videoSegments[this.currentSegmentIndex].data;
          this.videoElement.play();
        } else {
          this.videoElement.play().catch((error: any) => {
            console.error('Error playing video:', error);
          });
        }
      } else {
        this.videoElement.pause();
      }
    });

    $('.button-popper .fa-play').parent().click(() => {
      if (this.videoElement.paused) {
        this.videoElement.play().catch((error: any) => {
          console.error('Error playing video:', error);
        });
      } else {
        this.videoElement.pause();
      }
    });

    $('.button-popper .fa-forward').parent().click(() => {
      this.videoElement.currentTime += 10;
      if ((Math.floor(this.videoElement.currentTime) >= 29) && this.videoSegments[this.currentSegmentIndex + 1]?.data) {
        this.currentSegmentIndex++;
        this.videoElement.src = this.videoSegments[this.currentSegmentIndex].data;
        this.videoElement.currentTime += 10;
        this.videoElement.play();
      }
    });

    $('.button-popper .fa-backward').parent().click(() => {
      if (this.currentSegmentIndex > 0 && (Math.floor(this.videoElement.currentTime) === 0) && this.videoSegments[this.currentSegmentIndex]?.data) {
        this.currentSegmentIndex--;
        this.videoElement.src = this.videoSegments[this.currentSegmentIndex]?.data;
        this.videoElement.currentTime = 20;
        this.videoElement.play();
      } else {
        this.videoElement.currentTime -= 10;
        this.videoElement.play();
      }
    });
  }

  async fetchVideoSegment(startTime: number, endTime: number, fileName: string): Promise<string> {
    const url = this.api.url + `8000/video?startTime=${startTime}&endTime=${endTime}&fileName=${fileName}`;
    console.log(url);
    try {
      const response = await fetch(url);
      const arrayBuffer = await response.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      const blob = new Blob([uint8Array], { type: 'video/mp4' });
      const blobUrl = URL.createObjectURL(blob);
      return blobUrl;
    } catch (error) {
      console.error('Error fetching video segment:', error);
      throw error;
    }
  }

  formatTime(time: number): string {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(seconds).padStart(2, '0');
    return `${formattedMinutes}:${formattedSeconds}`;
  }

  toggleMute(): void {
    this.isMuted = !this.isMuted;
    if (this.videoElement) {
      this.videoElement.muted = this.isMuted;
    }
  }

  toggleFullScreen(): void {
    if (this.videoElement && !document.fullscreenElement) {
      if (this.videoElement.requestFullscreen) {
        this.videoElement.requestFullscreen();
      } else if ((this.videoElement as any).msRequestFullscreen) {
        (this.videoElement as any).msRequestFullscreen();
      } else if ((this.videoElement as any).mozRequestFullScreen) {
        (this.videoElement as any).mozRequestFullScreen();
      } else if ((this.videoElement as any).webkitRequestFullscreen) {
        (this.videoElement as any).webkitRequestFullscreen();
      }
      this.isFullScreen = true;
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
      this.isFullScreen = false;
    }
  }

  onProgressBarMouseDown(event: MouseEvent): void {
    this.isDragging = true;
    const progressBar = this.progressBar.nativeElement as HTMLDivElement;
    const rect = progressBar.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const progressPercentage = (offsetX / progressBar.offsetWidth) * 100;
    const seekTime = (progressPercentage * this.totalDuration) / 100;

    let relativeSeekTime = seekTime;

    for (let i = 0; i < this.videoSegments.length; i++) {
      if (seekTime >= this.videoSegments[i].startTime && seekTime <= this.videoSegments[i].endTime) {
        this.currentSegmentIndex = i;

        if (!this.videoSegments[i]?.data) {
          this.isLoading = true;
          this.fetchVideoSegment(this.videoSegments[i].startTime, this.videoSegments[i].endTime, this.selectedVideo).then((newBlobUrl: any) => {
            this.isLoading = false;
            this.videoSegments[i].data = newBlobUrl;
            this.videoElement.src = this.videoSegments[i].data;
            relativeSeekTime = seekTime - this.videoSegments[i].startTime;
            this.videoElement.currentTime = relativeSeekTime;
            this.videoElement.play();
            this.isDragging = false;
          });
        } else {
          this.videoElement.src = this.videoSegments[i].data;
          relativeSeekTime = seekTime - this.videoSegments[i].startTime;
          this.videoElement.currentTime = relativeSeekTime;
          this.videoElement.play();
          this.isDragging = false;
        }
        break;
      }
    }
  }

  onProgressBarMouseUp(): void {
    this.isDragging = false;
  }
}


interface VideoSegment {
  startTime: number;
  endTime: number;
  data: string | null;
}
