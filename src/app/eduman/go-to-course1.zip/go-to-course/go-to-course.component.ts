import { Component, ElementRef, Pipe, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EdumanModule } from '../eduman.module';
import { ToastService } from 'src/app/providers/toast/toast.service';
import { ApiService } from 'src/app/providers/api/api.service';
import { ActivatedRoute } from '@angular/router';
import { VideoService } from 'src/app/providers/video/video.service';

declare var $: any;


@Component({
  selector: 'app-go-to-course',
  standalone: true,
  imports: [CommonModule, EdumanModule],
  templateUrl: './go-to-course.component.html',
  styleUrls: ['./go-to-course.component.scss'],
})
export class GoToCourseComponent {
  @ViewChild('myVideo') videoPlayerDuration: ElementRef | any;
  courseList: any = [];
  courseSno: any;
  courseDetails: any;
  videoPlayer: any;
  isShowVideo: boolean = false;
  articale: any;
  // videoDuration: number = 0.0;
  remainder: number = 0.0;
  quotient: number = 0.0;
  cartTotalHours: string = '00:03:15.471';
  dateTime = new Date();
  videoUrl: any;

  constructor(
    private api: ApiService,
    private route: ActivatedRoute,
    private videoService: VideoService
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      if (params) {
        this.courseSno = params['courseSno'];
        this.getCourseDetails();
        this.videoPlayer = document.getElementById('videoPlayer');
        this.startVideoStreaming();
      }
    });
  }

  ngAfterViewInit() {
    const video: HTMLVideoElement = this.videoPlayerDuration.nativeElement;
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      console.log('Video duration:', video.duration);
      const durationInSeconds = video.duration;
      this.quotient = Math.floor(durationInSeconds / 60);
      this.remainder = parseFloat((durationInSeconds % 60).toFixed(0));

      console.log('Quotient:', this.quotient);
      console.log('Remainder:', this.remainder);
    };
  }

  toggleSection(curriculum: any) {
    curriculum.isExpanded = !curriculum?.isExpanded; // Toggle the expanded state
  }

  selectVideo(lecture: any): void {
    console.log(lecture);
    if (lecture?.videoSno) {
      this.isShowVideo = true;
      this.videoPlayer.src = lecture?.videoSno;
      this.videoPlayer?.play();
    } else {
      this.isShowVideo = false;
      this.articale = lecture?.articale;
    }
  }
  getTime(videoUrl: any) {
    // alert('in')
    const videoElement: HTMLVideoElement = this.videoPlayerDuration.nativeElement;

    // Load the video
    videoElement.src = 'https://swombclientblob.blob.core.windows.net/internals01/file_706aaaf4-063d-41b9-bb90-b87990fbaa69.mp4';

    // Once metadata is loaded, get the duration
    videoElement.onloadedmetadata = () => {
      var duration = videoElement.duration;
      return duration
    };
  }

  getCourseDetails() {
    let params: any = {};
    params.courseSno = this.courseSno;
    this.api
      .get('8010/api/lnt/get_courses_details', params)
      .subscribe((result) => {
        if (result) {
          this.courseDetails = result?.data?.length ? result?.data[0] : null;
          let lectureLength: number = 0;
          let totalVideoLength: number = 0;
          let totalArticaleLength: number = 0;
          let totalResourceLength: number = 0;
          if (this.courseDetails?.curriculum[0]?.lecture?.length) {
            this.selectVideo(this.courseDetails?.curriculum[0]?.lecture[0]);
            this.videoPlayer?.pause();
          }
          for (let curriculum of this.courseDetails?.curriculum) {
            lectureLength = lectureLength + (curriculum?.lecture?.length ?? 0);
            for (let lecture of curriculum?.lecture) {
              totalVideoLength = totalVideoLength + (lecture?.videoSno ? 1 : 0);
              totalArticaleLength =
                totalArticaleLength + (lecture?.articale ? 1 : 0);
              totalResourceLength =
                totalResourceLength + (lecture?.resourcesSno ? 1 : 0);
            }
          }
          this.courseDetails.lectureLength = lectureLength ?? 0;
          this.courseDetails.totalVideoLength = totalVideoLength ?? 0;
          this.courseDetails.totalArticaleLength = totalArticaleLength ?? 0;
          this.courseDetails.totalResourceLength = totalResourceLength ?? 0;
          console.log(this.courseDetails);
        }
      });
  }

  roundDuration(durationString: any) {
    const parts = durationString.split(":");
    const seconds = parseInt(parts[2]);
    const roundedSeconds = Math.round(seconds / 100) * 100;  // Round to nearest hundredth
    return parts[0] + ":" + parts[1] + ":" + roundedSeconds.toString().padStart(2, "0");
  }

  downloadResources(url: any) {
    const download = document.createElement('a');
    download.href = url;
    download.download = url.split('/').pop();
    download.click();
  }

  startVideoStreaming(): void {
    this.videoService.getVideoChunk().subscribe((blob: any) => {
      const videoBlob = new Blob([blob], { type: 'video/mp4' });
      this.videoUrl = URL.createObjectURL(videoBlob);
    });
  }
}
