import { CommonModule } from '@angular/common';
import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router, NavigationStart, NavigationEnd } from '@angular/router';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { Editor, NgxEditorModule } from 'ngx-editor';
import { CommonHeaderComponent } from 'src/app/eduman/common-header/common-header.component';
import { ApiService } from 'src/app/providers/api/api.service';
import { PhotoService } from 'src/app/providers/photoservice/photoservice.service';
import { FileUploadService } from 'src/app/providers/socket/socket.service';
import { ToastService } from 'src/app/providers/toast/toast.service';
import { TokenStorageService } from 'src/app/providers/token-storage.service';
import { Subscription } from 'rxjs';

declare var $: any;
declare var MultiSelectTag: any;

@Component({
  selector: 'app-add-course-content',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    NgxEditorModule,
    NgMultiSelectDropDownModule,
    CommonHeaderComponent
  ],
  templateUrl: './add-course-content.component.html',
  styleUrls: ['./add-course-content.component.scss'],
})
export class AddCourseContentComponent implements OnInit {
  form: FormGroup;

  inputLength!: number;
  isNewInput: boolean[] = [];
  languageList: any = [];
  expLevelTypeList: any = [];
  categoryList: any = [];
  subCategoryList: any = [];
  topicsList: any = [];
  courseImgUrl: any;

  courseVideoUrl: any;
  courseImage: any;
  courseVideo: any;
  files: any = [];
  deleteMediaList: any = [];
  courseVideoThumbnailUrl: string | undefined;
  currencyList: any = [];
  isLoad: boolean = false;
  editor: Editor = new Editor();
  editorTwo: Editor = new Editor();
  editorThree: Editor = new Editor();
  editorFour: Editor = new Editor();

  isFuctionEnabled: boolean = false;

  html = '';
  welcomeMessage: string = '';
  upload = { image: null, video: null };

  @ViewChild('images') images: ElementRef | any;
  @ViewChild('videos') videos: ElementRef | any;


  private routerSubscription: any = Subscription;

  showIntro: boolean = false;
  extensionVisible: boolean = false;
  lectureDescrip: boolean = false;
  showArticle: boolean = false;

  sentedCount: number = 0;
  totalCount: number = 0;

  settings: any = {
    singleSelection: false,
    idField: 'topicSno',
    textField: 'topicName',
    enableCheckAll: true,
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    allowSearchFilter: true,
    limitSelection: -1,
    clearSearchFilter: true,
    maxHeight: 197,
    itemsShowLimit: 3,
    searchPlaceholderText: 'Search topic',
    noDataAvailablePlaceholderText: 'No Data Found',
    closeDropDownOnSelection: false,
    showSelectedItemsAtTop: false,
    defaultOpen: false,
  };
  appUser: any = this.storage.getUser();
  isCurriculum: boolean = false;

  // @HostListener('window:beforeunload', ['$event'])
  // beforeunloadHandler(e: MouseEvent) {
  //   // e = e || window.event;
  //   console.log(e);
  //   e.preventDefault();
  //   if (e.clientX < 0 && e.clientY < 0) {
  //     console.log('close event');

  //     // alert('Window closed');
  //   } else {
  //     console.log('refreshed event');
  //     // alert('Window refreshed');
  //   }
  //   // return "Sure?";
  //   // For IE and Firefox prior to version 4
  //   if (e) {
  //     e.returnValue = false;
  //   }

  //   // For Safari
  //   return 'Sure?';
  // }

  constructor(
    private api: ApiService,
    private toastService: ToastService,
    private photoService: PhotoService,
    private fb: FormBuilder,
    private fileUploadService: FileUploadService,
    private storage: TokenStorageService,
    private router: Router
  ) {
    this.form = this.fb.group({
      courseSno: new FormControl(null),
      intendedLearnerForm: this.fb.group({
        courseIntendedSno: new FormControl(null),
        studentsLearn: new FormArray([]),
        requirements: new FormArray([]),
        courseFor: new FormArray([]),
      }),
      curriculum: new FormArray([]),
      courseForm: new FormGroup({
        title: new FormControl('', Validators.required),
        subtitle: new FormControl('', Validators.required),
        description: new FormControl('', Validators.required),
        basicInfo: new FormGroup({
          languageTypeCd: new FormControl('', Validators.required),
          expLevelTypeCd: new FormControl('', Validators.required),
          categorySno: new FormControl('', Validators.required),
          subCategorySno: new FormControl('', Validators.required),
          topicsSno: new FormControl('', Validators.required),
        }),
      }),
      priceForm: new FormGroup({
        currencySno: new FormControl(null, Validators.required),
        price: new FormControl(null, Validators.pattern('^[0-9]*$')),
      }),
      msgForm: new FormGroup({
        welcomeMsg: new FormControl('', Validators.required),
        congratulationsMsg: new FormControl('', Validators.required),
      }),
    });
  }

  subscribeToRouterEvents(){
    this.routerSubscription = this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationStart && !this.isFuctionEnabled) {
        // this.confirmdNavigation = false;
        const confirmNavigation = window.confirm('Are you sure you want to leave?');
        if (!confirmNavigation) {
          if (this.routerSubscription) {
            this.routerSubscription.unsubscribe();
          }
          this.router.navigateByUrl(this.router.url);
          this.subscribeToRouterEvents();
        }
      }
    });
  }

  ngOnInit(): void {
    this.subscribeToRouterEvents();
    this.isCurriculum = false;
    $(document).ready(() => {
      $(`#intended-learners`).addClass('actives');
      const subCategory: any = document.getElementById('subCategory');
      subCategory.addEventListener('change', (event: any) => {
        this.getTopics();
      });
      
    });
    this.getEnumExpLevel();
    this.getcategoryList();
    this.getEnumLanguage();
    for (let i = 0; i < 4; i++) {
      const control = this.intendedLearnerForm.get(
        'studentsLearn'
      ) as FormArray;
      control.push(this.createRequirementsDetails());
    }
    this.addRequirementsInfo();
    this.addCourseForInfo();
    this.getCurrencyList();
    this.curriculum.push(
      this.createCurriculumDetails({
        section: 'Introduction',
        endOfSection: '',
      })
    );
    this.getCurriculumItem(this.curriculum.length - 1).push(
      this.createeCurriculumItem({
        lecture: 'Introduction',
      })
    );
    // this.addCurriculum();'
  }

  ngOnDestroy(): void {
    this.editor.destroy();
    this.editorTwo.destroy();
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }

  get intendedLearnerForm(): FormGroup {
    return this.form.get('intendedLearnerForm') as FormGroup;
  }

  get courseForm(): FormGroup {
    return this.form.get('courseForm') as FormGroup;
  }

  get msgForm(): FormGroup {
    return this.form.get('msgForm') as FormGroup;
  }

  get priceForm(): FormGroup {
    return this.form.get('priceForm') as FormGroup;
  }

  get curriculum(): FormArray {
    return this.form.get('curriculum') as FormArray;
  }

  getLearnerDetails(): FormArray {
    return this.intendedLearnerForm.controls['studentsLearn'] as FormArray;
  }

  getRequirementsDetails(): FormArray {
    return this.intendedLearnerForm.controls['requirements'] as FormArray;
  }

  getCourseForDetails(): FormArray {
    return this.intendedLearnerForm.controls['courseFor'] as FormArray;
  }

  getCurriculumItem(index: number): FormArray {
    return this.curriculum.at(index).get('curriculumItem') as FormArray;
  }

  addCurriculum() {
    this.curriculum.push(this.createCurriculumDetails());
    this.showSectionTab(this.curriculum.length - 1);
    this.getCurriculumItem(this.curriculum.length - 1).push(
      this.createeCurriculumItem()
    );
    this.showCurriculumTab(
      this.curriculum.length - 1,
      this.getCurriculumItem(this.curriculum.length - 1).length - 1
    );
  }

  addCurriculumItem(i: number) {
    this.getCurriculumItem(i).push(this.createeCurriculumItem());
    this.showCurriculumTab(i, this.getCurriculumItem(i).length - 1);
  }

  createCurriculumDetails(data?: any): FormGroup {
    return this.fb.group({
      section: [data?.section ?? '', [Validators.required]],
      endOfSection: [data?.endOfSection ?? '', [Validators.nullValidator]],
      curriculumItem: new FormArray([]),
      isEdit: [false],
    });
  }

  createeCurriculumItem(data?: any): FormGroup {
    return this.fb.group({
      lecture: [data?.lecture ?? '', [Validators.required]],
      description: [data?.description ?? '', [Validators.nullValidator]],
      video: [data?.video, [Validators.nullValidator]],
      articale: [data?.articale ?? '', [Validators.nullValidator]],
      resources: [data?.resources, [Validators.nullValidator]],
      isEdit: [false],
      isShowContent: [false],
      isShowArticale: [false],
    });
  }

  addLearnersInfo() {
    if (this.getLearnerDetails().valid) {
      const control = this.intendedLearnerForm.get(
        'studentsLearn'
      ) as FormArray;
      control.push(this.createRequirementsDetails());
    } else {
      // msg -- please fill all field after add new learn
    }
  }

  addRequirementsInfo() {
    if (this.getRequirementsDetails().valid) {
      const control = this.intendedLearnerForm.get('requirements') as FormArray;
      control.push(this.createLearnDetails());
    } else {
      // msg -- please fill all field after add new learn
    }
  }

  addCourseForInfo() {
    if (this.getCourseForDetails().valid) {
      const control = this.intendedLearnerForm.get('courseFor') as FormArray;
      control.push(this.createCourseForDetails());
    } else {
      // msg -- please fill all field after add new learn
    }
  }

  createRequirementsDetails(): FormGroup {
    return this.fb.group({
      learn: [null, [Validators.required]],
    });
  }

  createLearnDetails(): FormGroup {
    return this.fb.group({
      prerequisites: ['', Validators.required],
    });
  }

  createCourseForDetails(): FormGroup {
    return this.fb.group({
      courseFor: ['', Validators.required],
    });
  }

  changePhoto1Img(e: any, fileFormat: any, type: any) {
    console.log(e.files);
    this.upload.image = structuredClone(e.files[0]);
    console.log(this.upload.image);
    this.photoService.onFileChange(e, fileFormat, type, (result: any) => {
      if (type == 'courseImage') {
        if (result != null) {
          this.courseImgUrl = result[0].mediaUrl;
          if (this.courseImage?.mediaSno) {
            this.deleteMediaList.push({
              mediaDetailSno: this.courseImage?.mediaDetailSno,
            });
          }
          this.courseImage = result[0];
          console.log(this.courseImage);
          this.images.nativeElement.value = '';
        }
      }
    });
  }

  changeVideo(e: any, fileFormat: any, type: any) {
    this.upload.video = structuredClone(e.files[0]);
    console.log(e.files[0]);
    // this.getVideoDuration(e.files[0]);
    this.photoService.onFileChange(e, fileFormat, type, (result: any) => {
      if (type == 'courseVideo') {
        if (result != null) {
          this.courseVideoUrl = result[0].mediaUrl;
          if (this.courseVideo?.mediaSno) {
            this.deleteMediaList.push({
              mediaDetailSno: this.courseVideo?.mediaDetailSno,
            });
          }
          this.courseVideo = result[0];
          console.log(this.courseVideo);
          this.videos.nativeElement.value = '';
        }
      }
    });
  }


  displayVideoThumbnail(videoFile: File) {
    const videoElement = document.createElement('video');
    videoElement.setAttribute('src', URL.createObjectURL(videoFile));
    videoElement.setAttribute('autoplay', 'true');
    videoElement.setAttribute('muted', 'true');
    videoElement.setAttribute('width', '160');
    videoElement.addEventListener('loadedmetadata', () => {
      const canvas = document.createElement('canvas');
      canvas.width = videoElement.videoWidth;
      canvas.height = videoElement.videoHeight;
      canvas
        .getContext('2d')
        ?.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
      const thumbnailUrl = canvas.toDataURL();
      console.log('Thumbnail URL:', thumbnailUrl);
      this.courseVideoThumbnailUrl = thumbnailUrl;
    });
  }

  next(type: any) {
    this.isCurriculum = true;
    console.log(type);
    $('.nav-link').removeClass('actives');
    $(`#${type}`).addClass('actives');

    $('.tab-pane').removeClass('show active');
    var targetTabId = $(`#${type}`).data('bs-target');
    console.log(targetTabId);
    $(targetTabId).addClass('show active');
  }

  selectImage(type: String) {
    if (type == 'courseImage') {
      $('#selectImage').click();
    }
  }

  selectVideo(type: String) {
    if (type == 'courseVideo') {
      $('#selectVideo').click();
    }
  }

  removeFile(type: any): void {
    if (type == 'courseImage') {
      this.courseImage = 'null';
    }
  }

  removeVideo(type: any): void {
    if (type == 'courseVideo') {
      this.courseVideo = 'null';
    }
  }

  getcategoryList() {
    let param: any = {};
    this.api.get('8010/api/lnt/get_categories', param).subscribe(
      (result) => {
        console.log(result);
        if (result != null) {
          this.categoryList = result?.data ?? [];
          if (this.categoryList?.length) {
            this.courseForm.get('basicInfo')?.patchValue({
              categorySno: this.categoryList[0]?.categorySno,
            });
            this.getSubCategoryList();
          }
        } else {
          this.toastService.showError('Something went wrong');
        }
      },
      (err) => {
        this.toastService.showError(err);
      }
    );
  }

  getCurrencyList() {
    let param: any = {};
    this.api.get('8010/api/lnt/get_currency', param).subscribe(
      (result) => {
        console.log(result);
        if (result != null) {
          if (result.data != null && result.data.length > 0) {
            this.currencyList = result.data;
          } else {
          }
        } else {
          this.toastService.showError('Something went wrong');
        }
      },
      (err) => {
        this.toastService.showError(err);
      }
    );
  }

  getSubCategoryList() {
    let param: any = {};
    console.log(this.courseForm.value);
    param.categorySno = this.courseForm.value.basicInfo?.categorySno;
    this.api.get('8010/api/lnt/get_sub_categories', param).subscribe(
      (result) => {
        console.log(result);
        if (result != null) {
          if (result.data != null) {
            this.subCategoryList = result?.data ?? [];
            if (this.subCategoryList?.length) {
              this.courseForm.get('basicInfo')?.patchValue({
                subCategorySno: this.subCategoryList[0]?.subCategorySno,
              });
              this.getTopics();
            } else {
            }
          }
        } else {
          this.toastService.showError('Something went wrong');
        }
      },
      (err) => {
        this.toastService.showError(err);
      }
    );
  }

  getTopics() {
    let param: any = {};
    console.log(this.courseForm.value);
    param.subCategorySno = this.courseForm.value.basicInfo?.subCategorySno;
    this.api.get('8010/api/lnt/get_topics', param).subscribe(
      (result) => {
        console.log(result);
        if (result != null) {
          this.topicsList = result?.data ?? [];
          // setTimeout(() => {
          //   new MultiSelectTag('topics', {
          //     placeholder: 'Select Topics',
          //     rounded: true,    // default true
          //     shadow: true,      // default false
          //     tagColor: {
          //       textColor: '#327b2c',
          //       borderColor: '#92e681',
          //       bgColor: '#eaffe6',
          //     },
          //     onChange: (values: any) => {
          //       let topicsSno = [];
          //       for (let i in values) {
          //         topicsSno.push(values[i]?.value);
          //       }
          //       this.courseForm.get('basicInfo')?.patchValue({
          //         topicsSno: topicsSno
          //       });
          //     }
          //   });
          // }, 1000);
        } else {
          this.toastService.showError('Something went wrong');
        }
      },
      (err) => {
        this.toastService.showError(err);
      }
    );
  }

  getEnumExpLevel() {
    let param: any = { codeType: 'exp_level_type_cd' };
    this.api.get('8010/api/lnt/get_enum', param).subscribe((result) => {
      if (result != null && result.data) {
        this.expLevelTypeList = result.data;
      }
    });
  }

  getEnumLanguage() {
    let param: any = { codeType: 'language_type_cd' };
    this.api.get('8010/api/lnt/get_enum', param).subscribe((result) => {
      if (result != null && result.data) {
        this.languageList = result.data;
      }
    });
  }

  saveIntendedLearners() {
    const body = this.intendedLearnerForm.value;
    console.log(body);
    this.api
      .post('8010/api/lnt/insert_course_intended', body)
      .subscribe((result) => {
        this.isLoad = false;
        console.log(result);
        if (result != null && result?.data) {
          this.toastService.showSuccess('Saved successfully');
        } else {
        }
      });
  }

  saveCourseLandingPage() {
    let body: any = {};
    body = this.courseForm.value;
    this.files = [];
    this.files.push(this.upload.image);
    this.files.push(this.upload.video);
    console.log(this.files);
    this.fileUploadService.send(this.files, (result: any) => {
      let mediaList: any = [];

      if (result && result.length > 0) {
        if (result[0].mediaType == 'JPEG') {
          let mediaObj1: any = {
            containerName: 'courseImage',
            mediaList: [],
            deleteMediaList: [],
          };
          mediaObj1.mediaList.push(result[0]);
          mediaList.push(mediaObj1);
        }
        if (result[1].mediaType == 'mp4') {
          let mediaObj2: any = {
            containerName: 'courseVideo',
            mediaList: [],
            deleteMediaList: [],
          };
          mediaObj2.mediaList.push(result[1]);
          mediaList.push(mediaObj2);
        }
      }
      if (mediaList.length > 0) {
        body.media = {
          mediaList: mediaList,
        };
      }
      console.log(body);
      this.api.post('8010/api/lnt/insert_course_landing_page', body).subscribe(
        (result) => {
          this.isLoad = false;
          if (result != null && result.data != null) {
            this.courseForm.patchValue({
              courseSno: result.data.courseLandingPageSno,
            });
            this.toastService.showSuccess('Successfully Saved');
          }
        },
        (err) => {
          this.isLoad = false;
          this.toastService.showError(err);
        }
      );
    });
  }

  saveMsg() {
    this.isLoad = true;
    let body: any = this.msgForm.value;
    this.api.post('8010/api/lnt/insert_course_msg', body).subscribe(
      (result) => {
        this.isLoad = false;
        console.log(result);
        if (result != null && result?.data) {
          this.clear();
          body.courseMsgSno = result.data.courseMsgSno;
          this.toastService.showSuccess('Saved successfully');
        } else {
        }
      },
      (err) => {
        this.isLoad = false;
        this.toastService.showError(err);
      }
    );
  }

  savePrice() {
    this.isLoad = true;
    let body: any = this.priceForm.value;
    this.api.post('8010/api/lnt/insert_course_price', body).subscribe(
      (result) => {
        this.isLoad = false;
        console.log(result);
        if (result != null && result?.data) {
          this.clear();
          body.coursePriceSno = result.data.coursePriceSno;

          this.toastService.showSuccess('Saved successfully');
        } else {
        }
      },
      (err) => {
        this.isLoad = false;
        this.toastService.showError(err);
      }
    );
  }

  clear() {
    this.msgForm.reset();
  }

  showSectionTab(i: number) {
    console.log(this.curriculum.at(i).value);
    console.log(!this.curriculum.at(i).value.isEdit);
    this.curriculum.at(i).patchValue({
      isEdit: !this.curriculum.at(i).value.isEdit,
    });
  }

  showCurriculumTab(i: number, j: number) {
    console.log(this.curriculum.at(i).value);
    console.log(!this.curriculum.at(i).value.isEdit);
    this.getCurriculumItem(i)
      .at(j)
      .patchValue({
        isEdit: !this.getCurriculumItem(i).at(j).value.isEdit,
      });
  }

  showContentType(i: number, j: number) {
    this.getCurriculumItem(i)
      .at(j)
      .patchValue({
        isShowContent: !this.getCurriculumItem(i).at(j).value.isShowContent,
      });
  }

  showExtension() { }

  addArticle() {
    this.showArticle = !this.showArticle;
  }

  removeCurriculum(i: number) {
    this.curriculum.removeAt(i);
  }

  addVideo(i: number, j: number) {
    const file = document.createElement('input');
    file.setAttribute('type', 'file');
    file.setAttribute('accept', '.mp4');
    file.onchange = (event: any) => {
      const files: File = event.target.files[0];
      this.getCurriculumItem(i).at(j).patchValue({
        video: files,
      });
      // alert(this.getCurriculumItem(i).at(j).value.video)
      // alert(JSON.stringify(this.getCurriculumItem(i).at(j).value.video))
      console.log(this.getCurriculumItem(i).at(j).value.video);
      this.showContentType(i, j);
    };
    file.click();
  }

  addResource(i: number, j: number) {
    const file = document.createElement('input');
    file.setAttribute('type', 'file');
    file.setAttribute('accept', '.pdf');
    file.onchange = (event: any) => {
      const files: File = event.target.files[0];
      this.getCurriculumItem(i).at(j).patchValue({
        resources: files,
      });
      console.log(this.getCurriculumItem(i).at(j).value.resources);
      this.showContentType(i, j);
    };
    file.click();
  }

  removeVideoLec(i: number, j: number) {
    this.getCurriculumItem(i).at(j).patchValue({
      video: null,
    });
  }

  removeArticale(i: number, j: number) {
    this.getCurriculumItem(i)
      .at(j)
      .patchValue({
        articale: null,
        isShowArticale: !this.getCurriculumItem(i).at(j).value.isShowArticale,
      });
  }

  removeResourceLec(i: number, j: number) {
    this.getCurriculumItem(i).at(j).patchValue({
      resources: null,
    });
  }

  removeLec(i: number, j: number) {
    this.getCurriculumItem(i).removeAt(j);
  }

  removeVideoArc(i: number, j: number) {
    this.getCurriculumItem(i)
      .at(j)
      .patchValue({
        articale: null,
        isShowArticale: !this.getCurriculumItem(i).at(j).value.isShowArticale,
      });
  }

  saveArticale(i: number, j: number) {
    this.getCurriculumItem(i)
      .at(j)
      .patchValue({
        isShowArticale: !this.getCurriculumItem(i).at(j).value.isShowArticale,
      });
  }

  showArticale(i: number, j: number) {
    this.getCurriculumItem(i)
      .at(j)
      .patchValue({
        isShowArticale: !this.getCurriculumItem(i).at(j).value.isShowArticale,
      });
    this.showContentType(i, j);
  }

  save() {
    let body: any = {};
    body = this.form.value;
    this.totalCount = 0;
    this.sentedCount = 0;

    this.uploadCurriculum(body?.curriculum, 0);
    let interval = setInterval(() => {
      if (this.totalCount == this.sentedCount) {
        clearInterval(interval);
        this.uploadCourse();
      }
    }, 1000);
  }

  uploadCourse() {
    this.isFuctionEnabled = true;
    this.isLoad = true;
    let body: any = {};
    body = this.form.value;
    this.files = [];
    if (this.upload?.image) {
      this.files.push(this.upload.image);
    }
    if (this.upload?.video) {
      this.files.push(this.upload.video);
    }
    this.fileUploadService.send(this.files, (result: any) => {
      let mediaList: any = [];
      if (result && result.length > 0) {
        if (this.upload?.image) {
          let mediaObj1: any = {
            containerName: 'courseImage',
            mediaList: [],
            deleteMediaList: [],
          };
          mediaObj1.mediaList.push(result[0]);
          mediaList.push(mediaObj1);
        }
        if (this.upload?.video) {
          let mediaObj2: any = {
            containerName: 'courseVideo',
            mediaList: [],
            deleteMediaList: [],
          };
          mediaObj2.mediaList.push(result[this.upload?.image ? 1 : 0]);
          mediaList.push(mediaObj2);
        }
      }

      for (let i in body?.curriculum) {
        for (let j in body?.curriculum[i]?.curriculumItem) {
          if (body?.curriculum[i]?.curriculumItem[j]?.video) {
            let mediaObj3: any = {
              containerName: `${i}-${j}-video`,
              mediaList: [],
              deleteMediaList: [],
            };
            mediaObj3.mediaList.push(
              body?.curriculum[i]?.curriculumItem[j]?.video
            );
            mediaList.push(mediaObj3);
          }
          if (body?.curriculum[i]?.curriculumItem[j]?.resources) {
            let mediaObj3: any = {
              containerName: `${i}-${j}-resources`,
              mediaList: [],
              deleteMediaList: [],
            };
            mediaObj3.mediaList.push(
              body?.curriculum[i]?.curriculumItem[j]?.resources
            );
            mediaList.push(mediaObj3);
          }
        }
      }

      if (mediaList.length > 0) {
        body.media = {
          mediaList: mediaList,
        };
      }
      let topics: any = [];
      for (let topic of body?.courseForm?.basicInfo?.topicsSno) {
        topics.push(topic?.topicSno);
      }
      body.courseForm.basicInfo.topicsSno = `{${topics}}`;
      body.appUserSno = this.appUser?.appUserSno;
      console.log("Hiiiii");
      console.log(body);

      this.api.post('8010/api/lnt/insert_course', body).subscribe(
        (result) => {
          this.isLoad = false;
          if (result != null && result.data != null) {
            this.router.navigate(['/instructorPage'], { replaceUrl: true });
            this.toastService.showSuccess('Successfully created');
          }
        },
        (err) => {
          this.isLoad = false;
          this.toastService.showError(err);
        }
      );
    });
  }

  async uploadCurriculum(curriculum: any, i: number) {
    this.uploadCurriculumItem(curriculum, curriculum[i]?.curriculumItem, i, 0);
  }

  async uploadCurriculumItem(curriculum: any, curriculumItem: any, i: number, j: number) {
    let files: any = [];
    if (curriculumItem[j]?.video) {
      files.push(curriculumItem[j]?.video);
    }
    if (curriculumItem[j]?.resources) {
      files.push(curriculumItem[j]?.resources);
    }
    if (files?.length) {
      ++this.totalCount;
      this.fileUploadService.send(files, (result: any) => {
        ++this.sentedCount;
        if (curriculumItem[j]?.video) {
          console.log(curriculumItem[j]?.video)
          this.getVideoDuration(curriculumItem[j]?.video, (result1: any) => {
            result[0].duration = result1;
            curriculumItem[j].video = result[0];

          })
        }
        if (curriculumItem[j]?.resources) {
          curriculumItem[j].resources = result[files?.length == 2 ? 1 : 0];
        }

        if (curriculumItem?.length - 1 == j) {
          this.uploadCurriculum(curriculum, i + 1);
        } else {
          this.uploadCurriculumItem(curriculum, curriculumItem, i, j + 1);
        }
      });
    } else {
      if (curriculumItem?.length - 1 == j) {
        this.uploadCurriculum(curriculum, i + 1);
      } else {
        this.uploadCurriculumItem(curriculum, curriculumItem, i, j + 1);
      }
    }
  }

  getVideoDuration(file: any, callback: any) {
    const video = document.createElement('video');
    video.src = URL.createObjectURL(file);
    video.onloadedmetadata = () => {
      var duration = this.formatDuration(video.duration);
      console.log('Video duration:', duration);
      callback(duration);
    };
  }

  formatDuration(durationInSeconds: number): string {
    const hours = Math.floor(durationInSeconds / 3600);
    const minutes = Math.floor((durationInSeconds % 3600) / 60);
    const seconds = durationInSeconds % 60;
    const formattedHours = hours > 0 ? `${hours}:` : ''; // Include hours only if they are greater than 0
    const formattedMinutes = `${minutes.toString().padStart(2, '0')}`;
    const formattedSeconds = `${seconds.toString().padStart(2, '0')}`;
    // alert(`${formattedHours}${formattedMinutes}:${formattedSeconds}`)
    return `${formattedHours}${formattedMinutes}:${formattedSeconds}`;
  }

  removeCourse(index: number): void {
    this.getCourseForDetails().removeAt(index);
  }

  removeRequirements(index: number): void {
    this.getRequirementsDetails().removeAt(index);
  }

  removeLearners(index: number): void {
    this.getLearnerDetails().removeAt(index);
  }
}
